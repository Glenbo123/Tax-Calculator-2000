import { Routes, Route, Navigate } from 'react-router-dom';
import { ThemeToggle } from './components/ThemeToggle';
import { LanguageSelector } from './components/LanguageSelector';
import { CrownLogo } from './components/CrownLogo';
import { Sidebar } from './components/Sidebar';
import { Calculator } from './pages/Calculator';
import { HelpButton } from './components/HelpButton';
import { Suspense, lazy } from 'react';
import { useTranslation } from 'react-i18next';
import './i18n/config';

const Comparison = lazy(() => import('./pages/Comparison').then(module => ({ default: module.Comparison })));
const Export = lazy(() => import('./pages/Export').then(module => ({ default: module.Export })));
const TaxYears = lazy(() => import('./pages/TaxYears').then(module => ({ default: module.TaxYears })));
const Benefits = lazy(() => import('./pages/Benefits').then(module => ({ default: module.Benefits })));
const Forms = lazy(() => import('./pages/Forms').then(module => ({ default: module.Forms })));
const PayeCalculator = lazy(() => import('./pages/PayeCalculator').then(module => ({ default: module.PayeCalculator })));
const TaxCodesExplained = lazy(() => import('./pages/TaxCodesExplained').then(module => ({ default: module.TaxCodesExplained })));
const TrainingModule = lazy(() => import('./pages/TrainingModule').then(module => ({ default: module.default })));

function App() {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen bg-govuk-grey dark:bg-gray-900 transition-colors">
      <header className="bg-govuk-blue dark:bg-primary-900 sticky top-0 z-[60] border-b border-white/10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Sidebar />
              <div className="flex items-center ml-3">
                <div className="flex-shrink-0">
                  <CrownLogo />
                </div>
                <div className="border-l border-white/30 pl-4 ml-4">
                  <h1 className="text-xl font-bold text-white leading-tight">
                    HM Revenue & Customs
                  </h1>
                  <h2 className="text-lg text-white/90 font-medium leading-tight">
                    {t('common.taxCalculator')}
                  </h2>
                </div>
              </div>
            </div>
            <div>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Suspense fallback={
          <div className="flex items-center justify-center min-h-[60vh]">
            <div className="text-govuk-blue animate-pulse">Loading...</div>
          </div>
        }>
          <Routes>
            <Route path="/" element={<Calculator />} />
            <Route path="/comparison" element={<Comparison />} />
            <Route path="/export" element={<Export />} />
            <Route path="/tax-years" element={<TaxYears />} />
            <Route path="/benefits" element={<Benefits />} />
            <Route path="/forms" element={<Forms />} />
            <Route path="/paye-calculator" element={<PayeCalculator />} />
            <Route path="/tax-codes-explained" element={<TaxCodesExplained />} />
            <Route path="/training" element={<TrainingModule />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Suspense>
      </main>

      <div className="fixed bottom-0 left-0 z-[70] p-4 bg-govuk-grey dark:bg-gray-900">
        <LanguageSelector />
      </div>
      <HelpButton />
    </div>
  );
}

export default App;