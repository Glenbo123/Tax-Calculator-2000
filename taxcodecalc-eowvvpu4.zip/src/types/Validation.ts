export interface ValidationResult {
  isValid: boolean;
  message?: string;
}