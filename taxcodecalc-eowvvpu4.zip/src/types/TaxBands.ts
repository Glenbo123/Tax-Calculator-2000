export interface TaxBand {
  band: string;
  rate: string;
  from: number;
  to: number | string;
  amount: number;
  tax: number;
}

export interface TaxRegion {
  name: string;
  code: string;
  bands: {
    name: string;
    rate: number;
    from: number;
    to: number | 'unlimited';
  }[];
}

export interface TaxCodeInfo {
  baseAllowance: number;
  isScottish: boolean;
  isWelsh?: boolean;
  isNegativeAllowance: boolean;
  hasMarriageAllowance: boolean;
  marriageAllowanceAmount?: number;
  specialCodeType?: string;
  taxRate?: number;
  isNonCumulative?: boolean;
}