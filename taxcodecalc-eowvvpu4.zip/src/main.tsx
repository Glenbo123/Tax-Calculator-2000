import './index.css';
import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import './i18n/config';
import './index.css';
import { debugUI } from './utils/debug';
import { ErrorBoundary } from './components/ErrorBoundary';

// Enable debug logging in development
if (process.env.NODE_ENV === 'development') {
  debugUI('Application starting in development mode');
  localStorage.setItem('debug', '*');
}

// Create a more robust error handler
const handleGlobalError = (event: ErrorEvent) => {
  console.error('Global error caught:', event.error);
  // Could add error reporting service here
  
  // Prevent the browser from showing its own error dialog
  event.preventDefault();
};

// Add global error handlers
window.addEventListener('error', handleGlobalError);
window.addEventListener('unhandledrejection', (event) => {
  console.error('Unhandled promise rejection:', event.reason);
  // Could add error reporting service here
});

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ErrorBoundary>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </ErrorBoundary>
  </React.StrictMode>
);