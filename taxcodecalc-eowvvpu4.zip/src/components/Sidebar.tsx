import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { 
  CalculatorIcon,
  ChartBarIcon,
  DocumentDuplicateIcon,
  CalendarIcon,
  GiftIcon,
  ClipboardDocumentListIcon,
  Bars3Icon,
  XMarkIcon,
  DocumentTextIcon,
  AcademicCapIcon
} from '@heroicons/react/24/outline';
import { clsx } from 'clsx';

export function Sidebar() {
  const { t } = useTranslation();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navigation = [
    { name: t('navigation.calculator'), href: '/', icon: CalculatorIcon },
    { name: 'PAYE Calculator', href: '/paye-calculator', icon: CalculatorIcon },
    { name: 'Tax Codes Explained', href: '/tax-codes-explained', icon: DocumentTextIcon },
    { name: 'Training Module', href: '/training', icon: AcademicCapIcon },
    { name: t('navigation.comparison'), href: '/comparison', icon: ChartBarIcon },
    { name: t('navigation.export'), href: '/export', icon: DocumentDuplicateIcon },
    { name: t('navigation.taxYears'), href: '/tax-years', icon: CalendarIcon },
    { name: t('navigation.benefits'), href: '/benefits', icon: GiftIcon },
    { name: t('navigation.forms'), href: '/forms', icon: ClipboardDocumentListIcon }
  ];

  const NavLinks = () => (
    <ul role="list" className="-mx-2 space-y-1">
      {navigation.map((item) => (
        <li key={item.name}>
          <Link
            to={item.href}
            className={clsx(
              location.pathname === item.href
                ? 'bg-govuk-blue/10 text-govuk-blue dark:bg-govuk-blue/20 dark:text-white'
                : 'text-gray-700 dark:text-gray-300 hover:text-govuk-blue hover:bg-govuk-blue/5 dark:hover:bg-govuk-blue/10',
              'group flex gap-x-3 rounded-md p-2 text-sm leading-6 font-semibold transition-colors'
            )}
            onClick={() => setIsMenuOpen(false)}
          >
            <item.icon
              className={clsx(
                location.pathname === item.href
                  ? 'text-govuk-blue dark:text-white'
                  : 'text-gray-400 group-hover:text-govuk-blue dark:group-hover:text-white',
                'h-5 w-5 shrink-0 transition-colors'
              )}
              aria-hidden="true"
            />
            {item.name}
          </Link>
        </li>
      ))}
    </ul>
  );

  return (
    <>
      <button
        type="button"
        className="text-white hover:text-white/80 focus:outline-none"
        onClick={() => setIsMenuOpen(!isMenuOpen)}
      >
        <span className="sr-only">Toggle menu</span>
        {isMenuOpen ? (
          <XMarkIcon className="h-6 w-6" aria-hidden="true" />
        ) : (
          <Bars3Icon className="h-6 w-6" aria-hidden="true" />
        )}
      </button>

      <div
        className={clsx(
          'fixed inset-0 z-[55] transition-transform duration-300 ease-in-out transform',
          isMenuOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <div 
          className="fixed inset-0 bg-gray-600 bg-opacity-75" 
          onClick={() => setIsMenuOpen(false)}
        />
        <div className="fixed inset-y-0 left-0 w-72 bg-white dark:bg-gray-800 shadow-xl transform transition-transform duration-300 ease-in-out">
          <div className="flex flex-col h-full">
            <div className="flex items-center justify-end p-4 border-b border-gray-200 dark:border-gray-700">
              <button
                onClick={() => setIsMenuOpen(false)}
                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
              >
                <XMarkIcon className="h-6 w-6" />
              </button>
            </div>
            <nav className="flex-1 px-6 py-4 overflow-y-auto">
              <NavLinks />
            </nav>
          </div>
        </div>
      </div>
    </>
  );
}