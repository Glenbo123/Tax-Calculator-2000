import { useState, useEffect } from 'react';
import { Tooltip } from './Tooltip';
import {
  QuestionMarkCircleIcon,
  ExclamationCircleIcon,
  CheckCircleIcon,
} from '@heroicons/react/24/outline';
import { clsx } from 'clsx';
import { validateAndProcessTaxCode } from '../utils/taxCodeValidator';
import DOMPurify from 'dompurify'; // Import DOMPurify

interface TaxCodeInputProps {
  value: string;
  onChange: (value: string) => void;
}

interface ValidationState {
  isValid: boolean;
  message?: string;
}

export function TaxCodeInput({ value, onChange }: TaxCodeInputProps) {
  const [validation, setValidation] = useState<ValidationState>({
    isValid: true,
  });
  const [isTouched, setIsTouched] = useState(false);
  const [taxCodeInfo, setTaxCodeInfo] = useState<{
    isScottish: boolean;
    isWelsh: boolean;
    isNegative: boolean;
    hasMarriageAllowance: boolean;
    isNonCumulative: boolean;
    isSpecialCode: boolean;
  }>({
    isScottish: false,
    isWelsh: false,
    isNegative: false,
    hasMarriageAllowance: false,
    isNonCumulative: false,
    isSpecialCode: false,
  });

  const validateTaxCode = (code: string): ValidationState => {
    if (!code || code.trim() === '') {
      return { isValid: false, message: 'Tax code is required' };
    }

    const result = validateAndProcessTaxCode(code);
    if (!result.valid) {
      return {
        isValid: false,
        message: result.message || 'Invalid tax code format',
      };
    }

    return { isValid: true };
  };

  const getTaxCodeInfo = (code: string) => {
    // Handle empty code
    if (!code || code.trim() === '') {
      return {
        isScottish: false,
        isWelsh: false,
        isNegative: false,
        hasMarriageAllowance: false,
        isNonCumulative: false,
        isSpecialCode: false,
      };
    }

    const normalizedCode = code.toUpperCase();
    const isScottish = normalizedCode.startsWith('S');
    const isWelsh = normalizedCode.startsWith('C');
    const isNegative = normalizedCode.includes('K');
    const hasMarriageAllowance =
      normalizedCode.endsWith('M') || normalizedCode.endsWith('N');
    const isNonCumulative =
      normalizedCode.endsWith('W1') || normalizedCode.endsWith('M1');
    const isSpecialCode = ['BR', 'D0', 'D1', 'NT', '0T'].includes(
      normalizedCode
    );

    return {
      isScottish,
      isWelsh,
      isNegative,
      hasMarriageAllowance,
      isNonCumulative,
      isSpecialCode,
    };
  };

  const handleTaxCodeChange = (input: string) => {
    // Sanitize the input using DOMPurify *before* any processing
    const sanitizedInput = DOMPurify.sanitize(input);

    // If input is empty, still pass it to onChange but ensure validation is triggered
    if (!sanitizedInput || sanitizedInput.trim() === '') {
      setIsTouched(true);
      onChange(''); // Pass empty string for consistent behavior
      return;
    }

    // Convert to uppercase and trim
    const cleanedInput = sanitizedInput.trim().toUpperCase();

    // Check if it's a special tax code (BR, D0, D1, NT, 0T)
    if (['BR', 'D0', 'D1', 'NT', '0T'].includes(cleanedInput)) {
      setIsTouched(true);
      onChange(cleanedInput);
      return;
    }

    // Special handling for K codes - they should only have numbers after K
    if (
      cleanedInput.startsWith('K') ||
      cleanedInput.startsWith('SK') ||
      cleanedInput.startsWith('CK')
    ) {
      let kPrefix = 'K';
      if (cleanedInput.startsWith('SK')) kPrefix = 'SK';
      if (cleanedInput.startsWith('CK')) kPrefix = 'CK';

      const numbers = cleanedInput
        .substring(kPrefix.length)
        .replace(/[^0-9]/g, '');
      if (numbers.length > 0) {
        const validKCode = kPrefix + numbers.substring(0, 3); // Limit to 3 digits for K codes
        setIsTouched(true);
        onChange(validKCode);
        return;
      }
    }

    // For regular tax codes, filter allowed characters
    let validInput = '';
    for (const char of cleanedInput) {
      if (/[0-9SCKLTMNWYD1]/.test(char)) {
        //Allowed characters
        validInput += char;
      }
    }

    // Limit length for regular tax codes
    const maxLength = 7; // Maximum tax code length including all suffixes
    const truncatedInput = validInput.slice(0, maxLength);

    setIsTouched(true);
    onChange(truncatedInput);
  };

  useEffect(() => {
    if (isTouched) {
      setValidation(validateTaxCode(value));
      setTaxCodeInfo(getTaxCodeInfo(value));
    }
  }, [value, isTouched]);

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <label
          htmlFor="taxCode"
          className="block text-sm font-medium text-gray-700 dark:text-gray-300"
        >
          Tax Code
        </label>
        <Tooltip
          content={`Tax code format examples:
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      • 1257L - Standard tax code
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      • S1257L - Scottish tax rates
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      • C1257L - Welsh tax rates
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      • K475 - Negative allowance (adds £4,750 to taxable income)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      • SK475 - Scottish negative allowance
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      • CK475 - Welsh negative allowance
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      • 1257M - Marriage allowance recipient
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      • 1257N - Marriage allowance transferor
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      • 1257LW1/M1 - Non-cumulative calculation
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      • BR - All income taxed at basic rate
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      • D0 - All income taxed at higher rate
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      • D1 - All income taxed at additional rate
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      • NT - No tax deducted
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      • 0T - No personal allowance`}
        >
          <button className="text-govuk-blue dark:text-gray-400 hover:text-govuk-blue/80 dark:hover:text-gray-300 focus:outline-none">
            <QuestionMarkCircleIcon className="h-5 w-5" />
          </button>
        </Tooltip>
      </div>
      <div className="relative">
        <input
          type="text"
          id="taxCode"
          value={value}
          onChange={(e) => handleTaxCodeChange(e.target.value)}
          onBlur={() => setIsTouched(true)}
          maxLength={7}
          className={clsx(
            'block w-full sm:text-sm border rounded-md dark:bg-gray-800 dark:text-white uppercase pr-10',
            'focus:outline-none focus:ring-2 focus:ring-offset-0',
            validation.isValid
              ? 'border-gray-300 dark:border-gray-700 focus:ring-govuk-blue focus:border-govuk-blue'
              : 'border-red-300 dark:border-red-700 focus:ring-red-500 focus:border-red-500'
          )}
          placeholder="e.g., 1257L, K475"
        />
        {isTouched && (
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
            {validation.isValid ? (
              <CheckCircleIcon className="h-5 w-5 text-green-500" />
            ) : (
              <ExclamationCircleIcon className="h-5 w-5 text-red-500" />
            )}
          </div>
        )}
      </div>
      {isTouched && !validation.isValid && (
        <p className="mt-2 text-sm text-red-600 dark:text-red-400">
          {validation.message}
        </p>
      )}
      <div className="flex flex-wrap gap-2 mt-2">
        {taxCodeInfo.isSpecialCode && (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200">
            Special Rate
          </span>
        )}
        {taxCodeInfo.isScottish && (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
            Scottish Rates
          </span>
        )}
        {taxCodeInfo.isWelsh && (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
            Welsh Rates
          </span>
        )}
        {taxCodeInfo.isNegative && (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
            K Code
          </span>
        )}
        {taxCodeInfo.hasMarriageAllowance && (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200">
            Marriage Allowance
          </span>
        )}
        {taxCodeInfo.isNonCumulative && (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200">
            Non-Cumulative
          </span>
        )}
      </div>
    </div>
  );
}
