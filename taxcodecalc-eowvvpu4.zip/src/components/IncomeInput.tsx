import { useState } from 'react';
import { IncomeType, IncomeSource, PaymentFrequency } from '../types';
import { Tab } from '@headlessui/react';
import { clsx } from 'clsx';
import { Tooltip } from './Tooltip';
import {
  QuestionMarkCircleIcon,
  PlusIcon,
  TrashIcon,
} from '@heroicons/react/24/outline';

interface IncomeInputProps {
  onIncomeChange: (amount: number) => void;
}

const INCOME_TYPES = [
  {
    id: 'bonus',
    label: 'Bonus/Commission',
    description: 'Performance-related pay or sales commission',
  },
  {
    id: 'overtime',
    label: 'Overtime',
    description: 'Additional hours worked beyond standard contract',
  },
  { id: 'tips', label: 'Tips', description: 'Gratuities and service charges' },
  {
    id: 'investment',
    label: 'Investment',
    description: 'Dividends, interest, and capital gains',
  },
  {
    id: 'rental',
    label: 'Rental',
    description: 'Income from property letting',
  },
  {
    id: 'other',
    label: 'Other',
    description: 'Any other regular or irregular income',
  },
] as const;

const PAYMENT_FREQUENCIES: { value: PaymentFrequency; label: string }[] = [
  { value: 'monthly', label: 'Monthly' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'bi-weekly', label: 'Every 2 weeks' },
  { value: 'four-weekly', label: 'Every 4 weeks' },
];

export function IncomeInput({ onIncomeChange }: IncomeInputProps) {
  const [incomeType, setIncomeType] = useState<IncomeType>('annual');
  const [displayAmount, setDisplayAmount] = useState<number>(50000);
  const [hoursPerWeek, setHoursPerWeek] = useState<number>(40);
  const [additionalIncomes, setAdditionalIncomes] = useState<IncomeSource[]>(
    []
  );

  const convertAmount = (
    value: number,
    fromType: IncomeType,
    toType: IncomeType
  ): number => {
    let annualValue = value;
    switch (fromType) {
      case 'monthly':
        annualValue = value * 12;
        break;
      case 'weekly':
        annualValue = value * 52;
        break;
      case 'hourly':
        annualValue = value * hoursPerWeek * 52;
        break;
    }

    switch (toType) {
      case 'monthly':
        return annualValue / 12;
      case 'weekly':
        return annualValue / 52;
      case 'hourly':
        return annualValue / (hoursPerWeek * 52);
      default:
        return annualValue;
    }
  };

  const handleAmountChange = (value: string) => {
    const numericValue = value === '' ? 0 : parseFloat(value);

    if (isNaN(numericValue) || numericValue < 0) {
      return;
    }

    const roundedValue = Math.round(numericValue * 100) / 100;
    setDisplayAmount(roundedValue);

    calculateTotalIncome(roundedValue, additionalIncomes);
  };

  const handleAdditionalIncomeChange = (
    index: number,
    updates: Partial<IncomeSource>
  ) => {
    const updatedIncomes = additionalIncomes.map((income, i) =>
      i === index ? { ...income, ...updates } : income
    );
    setAdditionalIncomes(updatedIncomes);
    calculateTotalIncome(displayAmount, updatedIncomes);
  };

  const addAdditionalIncome = () => {
    setAdditionalIncomes([
      ...additionalIncomes,
      {
        type: 'bonus',
        amount: 0,
        frequency: 'monthly',
        taxable: true,
        description: '',
      },
    ]);
  };

  const removeAdditionalIncome = (index: number) => {
    const updatedIncomes = additionalIncomes.filter((_, i) => i !== index);
    setAdditionalIncomes(updatedIncomes);
    calculateTotalIncome(displayAmount, updatedIncomes);
  };

  const calculateTotalIncome = (
    primaryAmount: number,
    additionalSources: IncomeSource[]
  ) => {
    let totalAnnual = convertAmount(primaryAmount, incomeType, 'annual');

    additionalSources.forEach((source) => {
      let annualAmount = source.amount;
      switch (source.frequency) {
        case 'monthly':
          annualAmount *= 12;
          break;
        case 'weekly':
          annualAmount *= 52;
          break;
        case 'bi-weekly':
          annualAmount *= 26;
          break;
        case 'four-weekly':
          annualAmount *= 13;
          break;
      }
      if (source.taxable) {
        totalAnnual += annualAmount;
      }
    });

    onIncomeChange(totalAnnual);
  };

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <h3 className="text-lg font-medium text-gray-900 dark:text-white">
            Primary Income
          </h3>
          <Tooltip content="Your main source of income. Select the type and enter the amount. For hourly rates, specify your weekly hours.">
            <button className="text-govuk-blue dark:text-gray-400 hover:text-govuk-blue/80 dark:hover:text-gray-300 focus:outline-none">
              <QuestionMarkCircleIcon className="h-5 w-5" />
            </button>
          </Tooltip>
        </div>

        <Tab.Group
          onChange={(index) => {
            const newType = ['annual', 'monthly', 'weekly', 'hourly'][
              index
            ] as IncomeType;
            const convertedAmount = convertAmount(
              displayAmount,
              incomeType,
              newType
            );
            setIncomeType(newType);
            setDisplayAmount(Math.round(convertedAmount * 100) / 100);
          }}
        >
          <Tab.List className="flex space-x-1 rounded-xl bg-primary-900/20 p-1">
            {['Annual', 'Monthly', 'Weekly', 'Hourly'].map((category) => (
              <Tab
                key={category}
                className={({ selected }) =>
                  clsx(
                    'w-full rounded-lg py-2.5 text-sm font-medium leading-5',
                    'ring-white/60 ring-offset-2 ring-offset-primary-400 focus:outline-none focus:ring-2',
                    selected
                      ? 'bg-white text-primary-700 shadow dark:bg-primary-900 dark:text-white'
                      : 'text-primary-100 hover:bg-white/[0.12] hover:text-white'
                  )
                }
              >
                {category}
              </Tab>
            ))}
          </Tab.List>
        </Tab.Group>

        <div className="space-y-4">
          <div>
            <label
              htmlFor="amount"
              className="block text-sm font-medium text-gray-700 dark:text-gray-300"
            >
              {incomeType.charAt(0).toUpperCase() + incomeType.slice(1)} Amount
            </label>
            <div className="mt-1 relative rounded-md shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <span className="text-gray-500 dark:text-gray-400 sm:text-sm">
                  £
                </span>
              </div>
              <input
                type="number"
                name="amount"
                id="amount"
                value={displayAmount || ''}
                onChange={(e) => handleAmountChange(e.target.value)}
                min="0"
                step="0.01"
                className="focus:ring-govuk-blue focus:border-govuk-blue block w-full pl-7 pr-12 sm:text-sm border-gray-300 rounded-md dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                placeholder="Enter amount"
              />
            </div>
          </div>

          {incomeType === 'hourly' && (
            <div>
              <label
                htmlFor="hours"
                className="block text-sm font-medium text-gray-700 dark:text-gray-300"
              >
                Hours per Week
              </label>
              <div className="mt-1">
                <input
                  type="number"
                  name="hours"
                  id="hours"
                  value={hoursPerWeek || ''}
                  onChange={(e) => {
                    const value = parseFloat(e.target.value);
                    if (!isNaN(value) && value >= 0 && value <= 168) {
                      setHoursPerWeek(value);
                      calculateTotalIncome(displayAmount, additionalIncomes);
                    }
                  }}
                  min="0"
                  max="168"
                  step="0.5"
                  className="focus:ring-govuk-blue focus:border-govuk-blue block w-full sm:text-sm border-gray-300 rounded-md dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                  placeholder="Enter hours"
                />
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white">
              Additional Income
            </h3>
            <Tooltip content="Add any additional sources of income such as bonuses, overtime, investments, or rental income. Each source can have its own payment frequency.">
              <button className="text-govuk-blue dark:text-gray-400 hover:text-govuk-blue/80 dark:hover:text-gray-300 focus:outline-none">
                <QuestionMarkCircleIcon className="h-5 w-5" />
              </button>
            </Tooltip>
          </div>
          <button
            onClick={addAdditionalIncome}
            className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-white bg-govuk-blue hover:bg-govuk-blue/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-govuk-blue"
          >
            <PlusIcon className="h-4 w-4 mr-1" />
            Add Income
          </button>
        </div>

        {additionalIncomes.map((income, index) => (
          <div
            key={index}
            className="bg-gray-50 dark:bg-gray-900/50 p-4 rounded-lg space-y-4"
          >
            <div className="flex items-center justify-between">
              <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Type
                  </label>
                  <select
                    value={income.type}
                    onChange={(e) =>
                      handleAdditionalIncomeChange(index, {
                        type: e.target.value as IncomeSource['type'],
                      })
                    }
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-govuk-blue focus:border-govuk-blue sm:text-sm rounded-md dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                  >
                    {INCOME_TYPES.map((type) => (
                      <option key={type.id} value={type.id}>
                        {type.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Frequency
                  </label>
                  <select
                    value={income.frequency}
                    onChange={(e) =>
                      handleAdditionalIncomeChange(index, {
                        frequency: e.target.value as PaymentFrequency,
                      })
                    }
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-govuk-blue focus:border-govuk-blue sm:text-sm rounded-md dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                  >
                    {PAYMENT_FREQUENCIES.map((freq) => (
                      <option key={freq.value} value={freq.value}>
                        {freq.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Amount
                  </label>
                  <div className="mt-1 relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-gray-500 dark:text-gray-400 sm:text-sm">
                        £
                      </span>
                    </div>
                    <input
                      type="number"
                      value={income.amount || ''}
                      onChange={(e) =>
                        handleAdditionalIncomeChange(index, {
                          amount: parseFloat(e.target.value) || 0,
                        })
                      }
                      className="focus:ring-govuk-blue focus:border-govuk-blue block w-full pl-7 pr-12 sm:text-sm border-gray-300 rounded-md dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                      placeholder="Enter amount"
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Description (Optional)
                  </label>
                  <input
                    type="text"
                    value={income.description || ''}
                    onChange={(e) =>
                      handleAdditionalIncomeChange(index, {
                        description: e.target.value,
                      })
                    }
                    className="mt-1 focus:ring-govuk-blue focus:border-govuk-blue block w-full sm:text-sm border-gray-300 rounded-md dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                    placeholder="Add details"
                  />
                </div>
              </div>
              <button
                onClick={() => removeAdditionalIncome(index)}
                className="ml-4 p-2 text-gray-400 hover:text-red-500 focus:outline-none"
              >
                <TrashIcon className="h-5 w-5" />
              </button>
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                checked={income.taxable}
                onChange={(e) =>
                  handleAdditionalIncomeChange(index, {
                    taxable: e.target.checked,
                  })
                }
                className="h-4 w-4 text-govuk-blue focus:ring-govuk-blue border-gray-300 rounded"
              />
              <label className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                This income is taxable
              </label>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
