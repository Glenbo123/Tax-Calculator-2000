import crownLogo from '../assets/hmrc-logo.svg';

export function CrownLogo() {
  return (
    <img
      src={crownLogo}
      alt="HMRC Crown Logo"
      width="48"
      height="48"
      className="h-12 w-12"
    />
  );
}