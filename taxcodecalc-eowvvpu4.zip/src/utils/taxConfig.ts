import { TaxRegion } from '../types';

export const UK_TAX_REGIONS: TaxRegion[] = [
  {
    name: 'England & NI',
    code: 'UK',
    bands: [
      { name: 'Personal Allowance', rate: 0, from: 0, to: 12570 },
      { name: 'Basic Rate', rate: 20, from: 12570, to: 50270 },
      { name: 'Higher Rate', rate: 40, from: 50270, to: 125140 },
      { name: 'Additional Rate', rate: 45, from: 125140, to: 'unlimited' }
    ]
  },
  {
    name: 'Scotland',
    code: 'S',
    bands: [
      { name: 'Personal Allowance', rate: 0, from: 0, to: 12570 },
      { name: 'Starter Rate', rate: 19, from: 12570, to: 14732 },
      { name: 'Basic Rate', rate: 20, from: 14732, to: 25688 },
      { name: 'Intermediate Rate', rate: 21, from: 25688, to: 43662 },
      { name: 'Higher Rate', rate: 42, from: 43662, to: 125140 },
      { name: 'Top Rate', rate: 47, from: 125140, to: 'unlimited' }
    ]
  }
];

export const NI_THRESHOLDS = {
  WEEKLY: {
    PRIMARY_THRESHOLD: 242,
    UPPER_EARNINGS_LIMIT: 967
  },
  MONTHLY: {
    PRIMARY_THRESHOLD: 1048,
    UPPER_EARNINGS_LIMIT: 4189
  },
  ANNUAL: {
    PRIMARY_THRESHOLD: 12576,
    UPPER_EARNINGS_LIMIT: 50268
  }
};

export const NI_RATES = {
  MAIN_RATE: 0.12,
  HIGHER_RATE: 0.02
};

export const MARRIAGE_ALLOWANCE = {
  TRANSFER_AMOUNT: 1260
};

export const MONTHS = [
  'April', 'May', 'June', 'July', 'August', 'September',
  'October', 'November', 'December', 'January', 'February', 'March'
];

export const WEEKS_IN_YEAR = 52;
export const MONTHS_IN_YEAR = 12;