import { TaxBand, TaxCodeInfo, TaxCalculationResult, ValidationResult } from '../types';
import { UK_TAX_REGIONS, NI_THRESHOLDS, NI_RATES, MONTHS } from './taxConfig';
import { parseTaxCode } from './taxCodeParser';
import { validateTaxCode } from './taxCodeValidator';
import { debugTax } from './debug';
import { 
  preciseAdd, 
  preciseSubtract, 
  preciseMultiply, 
  preciseDivide, 
  preciseRound 
} from './precisionCalculations';
import { memoize } from 'lodash';

/**
 * Validates input for tax calculations
 * @param salary Annual salary
 * @param taxCode Tax code
 * @returns ValidationResult with isValid flag and optional error message
 */
export function validateInput(salary: number, taxCode: string): ValidationResult {
  debugTax('Validating input - salary: %d, taxCode: %s', salary, taxCode);

  if (isNaN(salary) || salary === null) {
    debugTax('Invalid salary: not a number');
    return { isValid: false, message: 'Salary must be a number' };
  }

  if (salary < 0) {
    debugTax('Invalid salary: negative value');
    return { isValid: false, message: 'Salary cannot be negative' };
  }
  
  if (salary > 10000000) {
    debugTax('Invalid salary: exceeds maximum');
    return { isValid: false, message: 'Salary exceeds maximum allowed value' };
  }
  
  return validateTaxCode(taxCode);
}

/**
 * Calculates tax details based on salary and tax code
 * Memoized for performance optimization
 */
export const calculateTaxDetails = memoize(
  (
    annualSalary: number,
    taxCode: string,
    isCumulative: boolean,
    currentPeriod?: { type: 'month' | 'week'; number: number }
  ): TaxCalculationResult => {
    debugTax('Starting tax calculation with params:', {
      annualSalary,
      taxCode,
      isCumulative,
      currentPeriod
    });

    // Apply defaults if values are invalid
    const salary = isNaN(annualSalary) || annualSalary < 0 ? 0 : annualSalary;
    const tCode = taxCode || '1257L'; // Default tax code if none provided
    
    // Run validation but handle errors gracefully
    const validation = validateInput(salary, tCode);
    if (!validation.isValid) {
      debugTax('Validation failed: %s, using defaults', validation.message);
      // Rather than throwing an error, we'll use a default tax code
      // This is a fallback to prevent the UI from crashing
    }

    const taxCodeInfo = parseTaxCode(tCode);
    debugTax('Parsed tax code info:', taxCodeInfo);

    const taxRegion = UK_TAX_REGIONS.find(region => 
      taxCodeInfo.isScottish ? region.code === 'S' : region.code === 'UK'
    )!;
    debugTax('Selected tax region:', taxRegion.name);

    // Calculate adjusted income for K codes - they ADD to taxable income rather than reducing it
    let adjustedSalary = salary;
    let personalAllowance = calculatePersonalAllowance(salary, taxCodeInfo);
    
    // If it's a K code, the personal allowance is negative, and we need to add it to the salary
    // This effectively increases the taxable income
    if (taxCodeInfo.isNegativeAllowance) {
      // For K codes, personalAllowance is already negative, so adding it increases taxable income
      debugTax('K code detected, adding %d to taxable income', Math.abs(personalAllowance));
      
      // Check 50% overriding limit for K codes
      // Tax due from the K code adjustment should not exceed 50% of the original salary
      const kCodeAdjustment = Math.abs(personalAllowance);
      const maxTaxableAddition = salary * 0.5;
      
      if (kCodeAdjustment > maxTaxableAddition) {
        debugTax('K code adjustment exceeds 50% limit, capping at %d', maxTaxableAddition);
        personalAllowance = -maxTaxableAddition;
      }
    }
    
    debugTax('Calculated personal allowance: %d', personalAllowance);

    const monthlyGross = preciseDivide(salary, 12);
    const monthlyAllowance = preciseDivide(personalAllowance, 12);

    const monthlyBreakdown = MONTHS.map((month, index) => {
      const monthNumber = index + 1;
      const ytdGross = isCumulative ? preciseMultiply(monthlyGross, monthNumber) : monthlyGross;
      const ytdAllowance = isCumulative ? preciseMultiply(monthlyAllowance, monthNumber) : monthlyAllowance;
      
      // For standard tax codes (positive allowance), we subtract allowance from gross to get taxable
      // For K codes (negative allowance), adding the negative allowance effectively increases taxable income
      const taxable = Math.max(0, preciseSubtract(ytdGross, ytdAllowance));
      const incomeTax = calculateIncomeTax(taxable, taxRegion);
      const ni = calculateNI(monthlyGross);

      const currentMonthTax = isCumulative
        ? preciseDivide(incomeTax, monthNumber)
        : incomeTax;

      const detail = {
        month,
        monthNumber,
        gross: monthlyGross,
        taxFree: Math.max(0, monthlyAllowance), // Negative allowances (K codes) show as 0 tax-free
        taxable: preciseDivide(taxable, (isCumulative ? monthNumber : 1)),
        incomeTax: currentMonthTax,
        nationalInsurance: ni,
        netPay: preciseSubtract(monthlyGross, preciseAdd(currentMonthTax, ni))
      };

      debugTax('Month %d calculation:', monthNumber, detail);
      return detail;
    });

    // Calculate annual totals with precision
    const annualTax = monthlyBreakdown.reduce((sum, month) => 
      preciseAdd(sum, month.incomeTax), 0);
    const annualNI = monthlyBreakdown.reduce((sum, month) => 
      preciseAdd(sum, month.nationalInsurance), 0);

    if (currentPeriod) {
      debugTax('Applying current period adjustments:', currentPeriod);
      const periodIndex = currentPeriod.type === 'month' 
        ? currentPeriod.number - 1 
        : Math.floor(currentPeriod.number / (52/12)) - 1;
      
      if (periodIndex >= 0 && periodIndex < monthlyBreakdown.length) {
        const ytdBreakdown = monthlyBreakdown.slice(0, periodIndex + 1);
        const remainingMonths = monthlyBreakdown.slice(periodIndex + 1);
        
        remainingMonths.forEach(month => {
          month.incomeTax = ytdBreakdown[periodIndex].incomeTax;
          month.nationalInsurance = ytdBreakdown[periodIndex].nationalInsurance;
          month.netPay = ytdBreakdown[periodIndex].netPay;
        });
      }
    }

    const result = {
      annualSummary: {
        gross: salary,
        totalIncomeTax: annualTax,
        totalNI: annualNI,
        netAnnual: preciseSubtract(salary, preciseAdd(annualTax, annualNI))
      },
      monthlyBreakdown,
      incomeTaxBands: calculateTaxBands(salary, personalAllowance, taxRegion),
      niBands: calculateNIBands(salary)
    };

    debugTax('Final calculation result:', result);
    return result;
  },
  // Custom resolver function for memoization cache key
  (salary, taxCode, isCumulative, currentPeriod) => {
    // Create a unique cache key based on all parameters
    return `${salary}_${taxCode}_${isCumulative}_${currentPeriod ? 
      `${currentPeriod.type}_${currentPeriod.number}` : 'none'}`;
  }
);

/**
 * Calculates personal allowance based on salary and tax code
 * @param salary Annual salary
 * @param taxCodeInfo Parsed tax code information
 * @returns Calculated personal allowance
 */
function calculatePersonalAllowance(salary: number, taxCodeInfo: TaxCodeInfo): number {
  debugTax('Calculating personal allowance - salary: %d, taxCodeInfo:', salary, taxCodeInfo);
  
  let allowance = taxCodeInfo.baseAllowance;

  if (taxCodeInfo.hasMarriageAllowance) {
    allowance = preciseAdd(allowance, taxCodeInfo.marriageAllowanceAmount || 0);
    debugTax('Applied marriage allowance adjustment: %d', taxCodeInfo.marriageAllowanceAmount);
  }

  // Only apply high income reduction for positive allowances (not K codes)
  if (salary > 100000 && !taxCodeInfo.isNegativeAllowance) {
    const reduction = Math.floor(preciseDivide(preciseSubtract(salary, 100000), 2));
    allowance = Math.max(0, preciseSubtract(allowance, reduction));
    debugTax('Applied high income reduction: %d', reduction);
  }

  debugTax('Final personal allowance: %d', allowance);
  return allowance;
}

/**
 * Calculates income tax based on taxable income and tax region
 * @param taxableIncome Taxable income amount
 * @param taxRegion Tax region with tax bands
 * @returns Calculated income tax
 */
function calculateIncomeTax(taxableIncome: number, taxRegion: typeof UK_TAX_REGIONS[0]): number {
  debugTax('Calculating income tax - taxableIncome: %d, region: %s', taxableIncome, taxRegion.name);
  
  let tax = 0;
  let remainingIncome = taxableIncome;

  for (let i = 1; i < taxRegion.bands.length; i++) {
    const band = taxRegion.bands[i];
    const prevBand = taxRegion.bands[i - 1];
    
    // Handle 'unlimited' or other non-number values safely
    const bandTo = band.to === 'unlimited' ? Infinity : (band.to as number);
    const prevBandTo = prevBand.to === 'unlimited' ? Infinity : (prevBand.to as number);
    
    const bandWidth = preciseSubtract(bandTo, prevBandTo);
    const incomeInBand = Math.min(Math.max(0, remainingIncome), bandWidth);
    
    const bandTax = preciseMultiply(incomeInBand, preciseMultiply(band.rate, 0.01));
    tax = preciseAdd(tax, bandTax);
    remainingIncome = preciseSubtract(remainingIncome, incomeInBand);

    debugTax('Band calculation:', {
      bandName: band.name,
      rate: band.rate,
      incomeInBand,
      bandTax
    });

    if (remainingIncome <= 0) break;
  }

  debugTax('Total income tax: %d', tax);
  return preciseRound(tax);
}

/**
 * Calculates National Insurance contribution based on monthly income
 * @param monthlyIncome Monthly income amount
 * @returns Calculated NI contribution
 */
function calculateNI(monthlyIncome: number): number {
  debugTax('Calculating NI - monthlyIncome: %d', monthlyIncome);
  
  const thresholds = NI_THRESHOLDS.MONTHLY;
  let ni = 0;

  if (monthlyIncome > thresholds.UPPER_EARNINGS_LIMIT) {
    const higherRateNI = preciseMultiply(
      preciseSubtract(monthlyIncome, thresholds.UPPER_EARNINGS_LIMIT), 
      NI_RATES.HIGHER_RATE
    );
    const mainRateNI = preciseMultiply(
      preciseSubtract(thresholds.UPPER_EARNINGS_LIMIT, thresholds.PRIMARY_THRESHOLD), 
      NI_RATES.MAIN_RATE
    );
    ni = preciseAdd(higherRateNI, mainRateNI);
    
    debugTax('NI calculation (higher rate):', {
      higherRateNI,
      mainRateNI,
      total: ni
    });
  } else if (monthlyIncome > thresholds.PRIMARY_THRESHOLD) {
    ni = preciseMultiply(
      preciseSubtract(monthlyIncome, thresholds.PRIMARY_THRESHOLD), 
      NI_RATES.MAIN_RATE
    );
    debugTax('NI calculation (main rate): %d', ni);
  }

  return preciseRound(ni);
}

/**
 * Calculates tax bands based on annual salary and personal allowance
 * @param annualSalary Annual salary
 * @param personalAllowance Personal allowance amount
 * @param taxRegion Tax region with tax bands
 * @returns Array of tax bands with amounts and tax
 */
function calculateTaxBands(annualSalary: number, personalAllowance: number, taxRegion: typeof UK_TAX_REGIONS[0]): TaxBand[] {
  debugTax('Calculating tax bands - annualSalary: %d, personalAllowance: %d', annualSalary, personalAllowance);
  
  // For K codes (negative allowance), we need to add the negated value to the salary
  const adjustedSalary = annualSalary;
  
  // For K codes, we treat the personal allowance band differently
  // A negative allowance means zero in the personal allowance band
  const effectiveAllowance = Math.max(0, personalAllowance);
  
  const bands = taxRegion.bands.map((band, index) => {
    // Safely handle the 'from' value
    const from = index === 0 ? 0 : (taxRegion.bands[index - 1].to === 'unlimited' ? 
      Infinity : (taxRegion.bands[index - 1].to as number));
    
    const to = band.to === 'unlimited' ? 'No limit' : band.to;
    
    // Calculate amount with proper type handling
    const toValue = typeof to === 'string' ? Infinity : to;
    
    let amount = 0;
    let tax = 0;
    
    if (index === 0) {
      // Personal allowance band
      amount = Math.min(effectiveAllowance, adjustedSalary);
      tax = 0; // No tax on personal allowance
    } else {
      // For all other bands
      const lowerBound = Math.max(from, effectiveAllowance);
      amount = Math.max(0, Math.min(
        preciseSubtract(adjustedSalary, lowerBound),
        preciseSubtract(toValue, lowerBound)
      ));
      
      tax = preciseMultiply(amount, preciseMultiply(band.rate, 0.01));
    }

    const bandDetails = {
      band: band.name,
      rate: `${band.rate}%`,
      from,
      to,
      amount: preciseRound(amount),
      tax: preciseRound(tax)
    };

    debugTax('Tax band calculation:', bandDetails);
    return bandDetails;
  });

  return bands;
}

/**
 * Calculates National Insurance bands based on annual salary
 * @param annualSalary Annual salary
 * @returns Array of NI bands with amounts and tax
 */
function calculateNIBands(annualSalary: number): TaxBand[] {
  debugTax('Calculating NI bands - annualSalary: %d', annualSalary);
  
  const monthlyIncome = preciseDivide(annualSalary, 12);
  const thresholds = NI_THRESHOLDS.ANNUAL;

  const bands = [
    {
      band: 'Below Primary Threshold',
      rate: '0%',
      from: 0,
      to: thresholds.PRIMARY_THRESHOLD,
      amount: Math.min(annualSalary, thresholds.PRIMARY_THRESHOLD),
      tax: 0
    },
    {
      band: 'Main Rate',
      rate: `${preciseMultiply(NI_RATES.MAIN_RATE, 100)}%`,
      from: thresholds.PRIMARY_THRESHOLD,
      to: thresholds.UPPER_EARNINGS_LIMIT,
      amount: Math.max(0, Math.min(
        preciseSubtract(annualSalary, thresholds.PRIMARY_THRESHOLD),
        preciseSubtract(thresholds.UPPER_EARNINGS_LIMIT, thresholds.PRIMARY_THRESHOLD)
      )),
      tax: preciseMultiply(calculateNI(monthlyIncome), 12)
    },
    {
      band: 'Higher Rate',
      rate: `${preciseMultiply(NI_RATES.HIGHER_RATE, 100)}%`,
      from: thresholds.UPPER_EARNINGS_LIMIT,
      to: 'No limit',
      amount: Math.max(0, preciseSubtract(annualSalary, thresholds.UPPER_EARNINGS_LIMIT)),
      tax: preciseMultiply(
        preciseMultiply(
          Math.max(0, preciseSubtract(monthlyIncome, NI_THRESHOLDS.MONTHLY.UPPER_EARNINGS_LIMIT)), 
          NI_RATES.HIGHER_RATE
        ), 
        12
      )
    }
  ];

  debugTax('NI bands calculation:', bands);
  return bands;
}