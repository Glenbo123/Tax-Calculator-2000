import { Decimal } from 'decimal.js';
import { debugTax } from './debug';

/**
 * Performs precise addition of two numbers
 * @param a First number
 * @param b Second number
 * @param precision Number of decimal places (default: 2)
 * @returns Precisely calculated sum
 */
export function preciseAdd(a: number, b: number, precision: number = 2): number {
  try {
    const decimalA = new Decimal(a);
    const decimalB = new Decimal(b);
    return decimalA.plus(decimalB).toDecimalPlaces(precision).toNumber();
  } catch (error) {
    debugTax('Error in preciseAdd:', error);
    // Fallback to standard arithmetic if Decimal operations fail
    return Math.round((a + b) * 10 ** precision) / 10 ** precision;
  }
}

/**
 * Performs precise subtraction of two numbers
 * @param a First number
 * @param b Second number to subtract from the first
 * @param precision Number of decimal places (default: 2)
 * @returns Precisely calculated difference
 */
export function preciseSubtract(a: number, b: number, precision: number = 2): number {
  try {
    const decimalA = new Decimal(a);
    const decimalB = new Decimal(b);
    return decimalA.minus(decimalB).toDecimalPlaces(precision).toNumber();
  } catch (error) {
    debugTax('Error in preciseSubtract:', error);
    // Fallback to standard arithmetic if Decimal operations fail
    return Math.round((a - b) * 10 ** precision) / 10 ** precision;
  }
}

/**
 * Performs precise multiplication of two numbers
 * @param a First number
 * @param b Second number
 * @param precision Number of decimal places (default: 2)
 * @returns Precisely calculated product
 */
export function preciseMultiply(a: number, b: number, precision: number = 2): number {
  try {
    const decimalA = new Decimal(a);
    const decimalB = new Decimal(b);
    return decimalA.times(decimalB).toDecimalPlaces(precision).toNumber();
  } catch (error) {
    debugTax('Error in preciseMultiply:', error);
    // Fallback to standard arithmetic if Decimal operations fail
    return Math.round((a * b) * 10 ** precision) / 10 ** precision;
  }
}

/**
 * Performs precise division of two numbers
 * @param a Numerator
 * @param b Denominator
 * @param precision Number of decimal places (default: 2)
 * @returns Precisely calculated quotient
 */
export function preciseDivide(a: number, b: number, precision: number = 2): number {
  if (b === 0) {
    debugTax('Division by zero attempted');
    throw new Error('Division by zero');
  }
  
  try {
    const decimalA = new Decimal(a);
    const decimalB = new Decimal(b);
    return decimalA.dividedBy(decimalB).toDecimalPlaces(precision).toNumber();
  } catch (error) {
    debugTax('Error in preciseDivide:', error);
    // Fallback to standard arithmetic if Decimal operations fail
    return Math.round((a / b) * 10 ** precision) / 10 ** precision;
  }
}

/**
 * Rounds a number to a specified number of decimal places with precision
 * @param value Number to round
 * @param precision Number of decimal places (default: 2)
 * @returns Rounded number
 */
export function preciseRound(value: number, precision: number = 2): number {
  try {
    const decimal = new Decimal(value);
    return decimal.toDecimalPlaces(precision).toNumber();
  } catch (error) {
    debugTax('Error in preciseRound:', error);
    // Fallback to standard rounding if Decimal operations fail
    return Math.round(value * 10 ** precision) / 10 ** precision;
  }
}

/**
 * Formats a number as currency with precise handling
 * @param amount Amount to format
 * @param locale Locale for formatting (default: 'en-GB')
 * @param currency Currency code (default: 'GBP')
 * @returns Formatted currency string
 */
export function formatPreciseCurrency(
  amount: number, 
  locale: string = 'en-GB', 
  currency: string = 'GBP'
): string {
  try {
    // Use Decimal for precise representation of the amount
    const preciseAmount = new Decimal(amount).toDecimalPlaces(2).toNumber();
    
    return new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(preciseAmount);
  } catch (error) {
    debugTax('Error in formatPreciseCurrency:', error);
    // Fallback to standard formatting if Decimal operations fail
    return new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  }
}